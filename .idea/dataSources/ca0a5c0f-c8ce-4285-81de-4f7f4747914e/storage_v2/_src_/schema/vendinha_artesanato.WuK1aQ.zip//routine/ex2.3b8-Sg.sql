create
    definer = root@localhost function ex2(valor_total int) returns int
begin
 declare lucro int;

 set lucro = (valor_total - (valor_total * 0.3));

 return lucro;

end;

