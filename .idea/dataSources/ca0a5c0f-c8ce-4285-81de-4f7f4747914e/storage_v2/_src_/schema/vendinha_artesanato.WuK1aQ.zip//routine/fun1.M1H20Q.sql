create
    definer = root@localhost function fun1(nome varchar(200)) returns varchar(200)
begin
 declare primeiro_nome varchar(200);
 declare ultimo_sobrenome varchar(200);
 set primeiro_nome = SPLIT_STR(nome, ' ', 1);
 set ultimo_sobrenome = SPLIT_STR(nome, ' ', 3);
 return concat(primeiro_nome, ' ', ultimo_sobrenome);
end;

