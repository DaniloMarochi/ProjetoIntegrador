create definer = root@localhost trigger trg2
    before insert
    on cliente
    for each row
begin
declare msg varchar(255);
if(new.email not like '%@%') then
 set msg = "Email inválido";
 signal sqlstate '45000' set message_text = msg;
 end if;
end;

