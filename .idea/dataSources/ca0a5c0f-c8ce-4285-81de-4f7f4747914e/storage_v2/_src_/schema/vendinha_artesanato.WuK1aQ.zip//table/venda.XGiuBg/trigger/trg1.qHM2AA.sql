create definer = root@localhost trigger trg1
    before insert
    on venda
    for each row
begin
	update artesanato
	set artesanato.estoque = artesanato.estoque - new.qtd_artesanato
	where artesanato.id_artesanato = new.id_artesanato;
 end;

