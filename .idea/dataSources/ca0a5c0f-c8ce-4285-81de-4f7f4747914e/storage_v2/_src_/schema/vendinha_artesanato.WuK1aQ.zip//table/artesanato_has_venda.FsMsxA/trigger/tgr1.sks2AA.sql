create definer = root@localhost trigger tgr1
    after insert
    on artesanato_has_venda
    for each row
begin
update artesanato
 set artesanato.estoque = artesanato.estoque - venda.qtd_artesanato
 where artesanato.id_artesanato = artesanato_has_venda.artesanato_id_artesanato;
end;

